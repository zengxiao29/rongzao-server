# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, jsonify
import pandas as pd
import re
import base64
from io import BytesIO

app = Flask(__name__)

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/data-analysis')
def data_analysis():
    """数据分析页面"""
    return render_template('data_analysis.html')

@app.route('/test')
def test():
    """测试页面"""
    return render_template('test.html')

@app.route('/project-management')
def project_management():
    """项目管理页面"""
    return render_template('project_management.html')

@app.route('/production-management')
def production_management():
    """生产管理页面"""
    return render_template('production_management.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """处理Excel文件上传"""
    print('收到文件上传请求')

    if 'file' not in request.files:
        print('错误：请求中没有文件')
        return jsonify({'error': '没有文件'}), 400

    file = request.files['file']
    if file.filename == '':
        print('错误：文件名为空')
        return jsonify({'error': '未选择文件'}), 400

    print(f'开始处理文件: {file.filename}')

    try:
        # 读取Excel文件
        df = pd.read_excel(file)
        print(f'成功读取Excel文件，共 {len(df)} 行数据')

        # 处理数据
        result = process_data(df)
        print(f'数据处理完成，共 {len(result["products"])} 个商品')

        return jsonify(result)
    except Exception as e:
        print(f'处理文件时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def process_data(df):
    """处理Excel数据，生成商品销量统计"""
    # 商品名称去重：移除颜色、尺码等后缀信息
    def normalize_product_name(name):
        # 移除常见的颜色、尺码后缀
        # 例如：--蓝马甲, -58, 58CM, -XS, -61等
        name = str(name)
        # 移除 -- 后面的内容
        name = re.sub(r'--.*', '', name)
        # 移除 - 后面跟着数字或字母的内容（尺码）
        name = re.sub(r'-\s*\d+[A-Za-z]*', '', name)
        name = re.sub(r'-\s*[A-Za-z]+', '', name)
        # 移除末尾的数字+单位（如 58CM）
        name = re.sub(r'\d+CM$', '', name)
        name = re.sub(r'\d+$', '', name)
        return name.strip()

    # 标准化商品名称
    df['标准化商品名称'] = df['商品名称'].apply(normalize_product_name)

    # 计算销量：订购数减去退款成功的订单
    def calculate_sales(group):
        total = group['订购数'].sum()
        refunded = group[group['是否退款'] == '退款成功']['订购数'].sum()
        return total - refunded

    # 按标准化商品名称分组计算销量
    sales_data = df.groupby('标准化商品名称').apply(calculate_sales).reset_index()
    sales_data.columns = ['商品名称', '销量']

    # 按销量降序排序
    sales_data = sales_data.sort_values('销量', ascending=False)

    # 转换为前端可用的格式
    result = {
        'products': sales_data['商品名称'].tolist(),
        'sales': sales_data['销量'].tolist()
    }

    return result

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)