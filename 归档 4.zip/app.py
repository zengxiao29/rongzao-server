# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, jsonify, send_from_directory
import pandas as pd
import re
import base64
from io import BytesIO
import os
import sqlite3
import hashlib
import json

app = Flask(__name__)

# 数据库配置
DB_PATH = os.path.join(os.path.dirname(__file__), 'rongzao.db')

def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def calculate_record_hash(row):
    """计算记录的哈希值（基于所有字段）"""
    # 将所有字段按固定顺序拼接成字符串
    field_values = []
    for col in sorted(row.index):
        # 处理NaN值
        value = row[col]
        if pd.isna(value):
            value = ''
        field_values.append(str(value))

    # 计算MD5哈希
    hash_string = '|'.join(field_values)
    return hashlib.md5(hash_string.encode('utf-8')).hexdigest()

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/data-analysis')
def data_analysis():
    """数据分析页面"""
    return render_template('data_analysis.html')

@app.route('/test')
def test():
    """测试页面"""
    return render_template('test.html')

@app.route('/project-management')
def project_management():
    """项目管理页面"""
    return render_template('project_management.html')

@app.route('/production-management')
def production_management():
    """生产管理页面"""
    return render_template('production_management.html')

@app.route('/analyse')
def analyse():
    """数据分析页面"""
    return render_template('analyse.html')

@app.route('/<path:filename>')
def serve_static_file(filename):
    """提供静态文件服务"""
    return send_from_directory('.', filename)

@app.route('/api/analyse/config', methods=['GET'])
def get_analyse_config():
    """获取 tab 配置"""
    import json
    import os

    config_file = os.path.join(os.path.dirname(__file__), 'tab_config.json')
    if os.path.exists(config_file):
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        return jsonify(config)
    else:
        return jsonify({'tabs': []})

@app.route('/api/analyse/config', methods=['POST'])
def save_analyse_config():
    """保存 tab 配置"""
    import json
    import os

    config_file = os.path.join(os.path.dirname(__file__), 'tab_config.json')

    try:
        config = request.json
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyse/data', methods=['GET'])
def get_analyse_data():
    """从数据库获取分析数据"""
    print('收到数据分析请求')

    try:
        # 读取 tab 配置
        config_file = os.path.join(os.path.dirname(__file__), 'tab_config.json')
        tabs_config = []
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                tabs_config = config.get('tabs', [])

        print(f'读取到 {len(tabs_config)} 个 tab 配置')

        # 从数据库读取数据
        conn = get_db_connection()
        cursor = conn.cursor()

        # 读取所有订单数据
        cursor.execute('SELECT * FROM OrderDetails')
        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()

        # 转换为DataFrame
        df = pd.DataFrame(rows, columns=columns)
        conn.close()

        print(f'从数据库读取到 {len(df)} 条记录')

        # 过滤掉退款的订单
        df_filtered = df[df['是否退款'] != '退款成功'].copy()

        print(f'过滤退款后剩余 {len(df_filtered)} 行数据')

        # 为每个 tab 生成数据
        tabs_data = []

        for tab in tabs_config:
            tab_name = tab['name']
            mappings = tab['mappings']  # [{'product': '商品名称', 'type': '商品类型'}]

            # 统计该 tab 下的商品类型数据
            type_stats = {}

            # 为每行商品标记是否已匹配
            df_filtered['已匹配'] = False

            for mapping in mappings:
                original_product = mapping['product']
                mapped_type = mapping['type']

                # 查找匹配的商品行（子串匹配，只匹配未匹配的行）
                mask = ~df_filtered['已匹配'] & df_filtered['商品名称'].str.contains(original_product, na=False)
                matching_rows = df_filtered[mask]

                print(f'匹配 "{original_product}": 找到 {len(matching_rows)} 行')

                if len(matching_rows) > 0:
                    # 标记这些行为已匹配
                    df_filtered.loc[matching_rows.index, '已匹配'] = True

                    # 计算有效订购数
                    valid_orders = matching_rows['订购数'].sum()

                    # 计算让利后金额（如果有此列）
                    discount_amount = 0
                    if '让利后金额' in df_filtered.columns:
                        discount_amount = matching_rows['让利后金额'].sum()

                    if mapped_type not in type_stats:
                        type_stats[mapped_type] = {
                            'valid_orders': 0,
                            'discount_amount': 0
                        }

                    type_stats[mapped_type]['valid_orders'] += valid_orders
                    type_stats[mapped_type]['discount_amount'] += discount_amount

            # 转换为列表格式
            tab_data = {
                'name': tab_name,
                'data': [
                    {
                        'product_type': product_type,
                        'valid_orders': int(stats['valid_orders']),
                        'discount_amount': float(stats['discount_amount'])
                    }
                    for product_type, stats in type_stats.items()
                ]
            }

            tabs_data.append(tab_data)

        return {
            'tabs': tabs_data
        }
    except Exception as e:
        print(f'处理数据时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyse/upload', methods=['POST'])
def analyse_upload():
    """处理 Excel 文件上传并上传到数据库"""
    print('收到 analyse 文件上传请求')

    if 'file' not in request.files:
        print('错误：请求中没有文件')
        return jsonify({'error': '没有文件'}), 400

    file = request.files['file']
    if file.filename == '':
        print('错误：文件名为空')
        return jsonify({'error': '未选择文件'}), 400

    print(f'开始处理文件: {file.filename}')

    try:
        # 直接上传到数据库
        return upload_to_database_internal(file)
    except Exception as e:
        print(f'处理文件时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """处理Excel文件上传"""
    print('收到文件上传请求')

    if 'file' not in request.files:
        print('错误：请求中没有文件')
        return jsonify({'error': '没有文件'}), 400

    file = request.files['file']
    if file.filename == '':
        print('错误：文件名为空')
        return jsonify({'error': '未选择文件'}), 400

    print(f'开始处理文件: {file.filename}')

    try:
        # 读取Excel文件
        df = pd.read_excel(file)
        print(f'成功读取Excel文件，共 {len(df)} 行数据')

        # 处理数据
        result = process_data(df)
        print(f'数据处理完成，共 {len(result["products"])} 个商品')

        return jsonify(result)
    except Exception as e:
        print(f'处理文件时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def process_data(df):
    """处理Excel数据，生成商品销量统计"""
    # 商品名称去重：移除颜色、尺码等后缀信息
    def normalize_product_name(name):
        # 移除常见的颜色、尺码后缀
        # 例如：--蓝马甲, -58, 58CM, -XS, -61等
        name = str(name)
        # 移除 -- 后面的内容
        name = re.sub(r'--.*', '', name)
        # 移除 - 后面跟着数字或字母的内容（尺码）
        name = re.sub(r'-\s*\d+[A-Za-z]*', '', name)
        name = re.sub(r'-\s*[A-Za-z]+', '', name)
        # 移除末尾的数字+单位（如 58CM）
        name = re.sub(r'\d+CM$', '', name)
        name = re.sub(r'\d+$', '', name)
        return name.strip()

    # 标准化商品名称
    df['标准化商品名称'] = df['商品名称'].apply(normalize_product_name)

    # 计算销量：订购数减去退款成功的订单
    def calculate_sales(group):
        total = group['订购数'].sum()
        refunded = group[group['是否退款'] == '退款成功']['订购数'].sum()
        return total - refunded

    # 按标准化商品名称分组计算销量
    sales_data = df.groupby('标准化商品名称').apply(calculate_sales).reset_index()
    sales_data.columns = ['商品名称', '销量']

    # 按销量降序排序
    sales_data = sales_data.sort_values('销量', ascending=False)

    # 转换为前端可用的格式
    result = {
        'products': sales_data['商品名称'].tolist(),
        'sales': sales_data['销量'].tolist()
    }

    return result

@app.route('/api/db/upload', methods=['POST'])
def upload_to_database():
    """上传Excel数据到数据库"""
    print('收到数据库上传请求')

    if 'file' not in request.files:
        print('错误：请求中没有文件')
        return jsonify({'error': '没有文件'}), 400

    file = request.files['file']
    if file.filename == '':
        print('错误：文件名为空')
        return jsonify({'error': '未选择文件'}), 400

    print(f'开始处理文件: {file.filename}')

    try:
        return upload_to_database_internal(file)
    except Exception as e:
        print(f'处理文件时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def upload_to_database_internal(file):
    """内部函数：上传Excel数据到数据库"""
    print(f'开始处理文件: {file.filename}')

    # 读取Excel文件
    df = pd.read_excel(file)
    print(f'成功读取Excel文件，共 {len(df)} 行数据')

    # 将所有Timestamp类型转换为字符串
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].astype(str)
        # 将NaT（Not a Time）转换为空字符串
        df[col] = df[col].where(pd.notna(df[col]), '')

    # 应用层去重：处理Excel文件内部的重复
    df_deduped = df.drop_duplicates(keep='first')
    print(f'Excel内去重: {len(df)} -> {len(df_deduped)} 条记录')

    # 插入数据库
    conn = get_db_connection()
    cursor = conn.cursor()

    success_count = 0
    duplicate_count = 0
    error_count = 0

    # 准备插入SQL
    insert_sql = '''
        INSERT OR IGNORE INTO OrderDetails (
            record_hash, 店铺类型, 店铺名称, 分销商名称, 单据编号, 订单类型,
            拍单时间, 付款时间, 审核时间, 会员代码, 会员名称, 内部便签, 业务员,
            建议仓库, 建议快递, 到账, 商品图片, 品牌, 商品税率, 商品代码,
            商品名称, 商品简称, 规格代码, 规格名称, 商品备注, 代发订单, 订单标记,
            预计发货时间, 订购数, 总重量, 折扣, 标准进价, 标准单价, 标准金额,
            实际单价, 实际金额, 让利后金额, 让利金额, 物流费用, 成本总价,
            买家备注, 卖家备注, 制单人, 商品实际利润, 商品标准利润, 商品已发货数量,
            平台旗帜, 发货时间, 原产地, 平台商品名称, 平台规格名称, 供应商,
            赠品来源, 买家支付金额, 平台支付金额, 其他服务费, 发票种类,
            发票抬头类型, 发票类型, 开户行, 账号, 发票电话, 发票地址, 收货邮箱,
            周期购商品, 平台单号, 到账时间, 附加信息, 发票抬头, 发票内容,
            纳税人识别号, 收货人, 收货人手机, 邮编, 收货地址, 商品类别,
            二次备注, 商品单位, 币别, 会员邮箱, 订单标签, 平台交易状态,
            赠品, 是否退款, 地区信息, 确认收货时间, 作废
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    '''

    # 遍历每一行数据
    for idx, row in df_deduped.iterrows():
        try:
            # 计算哈希值
            record_hash = calculate_record_hash(row)

            # 准备数据
            data = (
                record_hash,
                row.get('店铺类型'), row.get('店铺名称'), row.get('分销商名称'),
                row.get('单据编号'), row.get('订单类型'), row.get('拍单时间'),
                row.get('付款时间'), row.get('审核时间'), row.get('会员代码'),
                row.get('会员名称'), row.get('内部便签'), row.get('业务员'),
                row.get('建议仓库'), row.get('建议快递'), row.get('到账'),
                row.get('商品图片'), row.get('品牌'), row.get('商品税率'),
                row.get('商品代码'), row.get('商品名称'), row.get('商品简称'),
                row.get('规格代码'), row.get('规格名称'), row.get('商品备注'),
                row.get('代发订单'), row.get('订单标记'), row.get('预计发货时间'),
                row.get('订购数'), row.get('总重量'), row.get('折扣'),
                row.get('标准进价'), row.get('标准单价'), row.get('标准金额'),
                row.get('实际单价'), row.get('实际金额'), row.get('让利后金额'),
                row.get('让利金额'), row.get('物流费用'), row.get('成本总价'),
                row.get('买家备注'), row.get('卖家备注'), row.get('制单人'),
                row.get('商品实际利润'), row.get('商品标准利润'),
                row.get('商品已发货数量'), row.get('平台旗帜'), row.get('发货时间'),
                row.get('原产地'), row.get('平台商品名称'), row.get('平台规格名称'),
                row.get('供应商'), row.get('赠品来源'), row.get('买家支付金额'),
                row.get('平台支付金额'), row.get('其他服务费'), row.get('发票种类'),
                row.get('发票抬头类型'), row.get('发票类型'), row.get('开户行'),
                row.get('账号'), row.get('发票电话'), row.get('发票地址'),
                row.get('收货邮箱'), row.get('周期购商品'), row.get('平台单号'),
                row.get('到账时间'), row.get('附加信息'), row.get('发票抬头'),
                row.get('发票内容'), row.get('纳税人识别号'), row.get('收货人'),
                row.get('收货人手机'), row.get('邮编'), row.get('收货地址'),
                row.get('商品类别'), row.get('二次备注'), row.get('商品单位'),
                row.get('币别'), row.get('会员邮箱'), row.get('订单标签'),
                row.get('平台交易状态'), row.get('赠品'), row.get('是否退款'),
                row.get('地区信息'), row.get('确认收货时间'), row.get('作废')
            )

            # 执行插入
            cursor.execute(insert_sql, data)

            if cursor.rowcount > 0:
                success_count += 1
            else:
                duplicate_count += 1

        except Exception as e:
            print(f'插入第 {idx} 行时出错: {e}')
            error_count += 1
            continue

    # 提交事务
    conn.commit()
    conn.close()

    print(f'上传完成: 成功={success_count}, 重复={duplicate_count}, 错误={error_count}')

    return {
        'success': True,
        'total': len(df_deduped),
        'success_count': success_count,
        'duplicate_count': duplicate_count,
        'error_count': error_count
    }

@app.route('/api/db/stats', methods=['GET'])
def get_database_stats():
    """获取数据库统计信息"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 获取总记录数
        cursor.execute('SELECT COUNT(*) as total FROM OrderDetails')
        total = cursor.fetchone()['total']

        # 获取去重后的单据编号数
        cursor.execute('SELECT COUNT(DISTINCT 单据编号) as unique_orders FROM OrderDetails')
        unique_orders = cursor.fetchone()['unique_orders']

        # 获取去重后的商品代码数
        cursor.execute('SELECT COUNT(DISTINCT 商品代码) as unique_products FROM OrderDetails')
        unique_products = cursor.fetchone()['unique_products']

        # 获取退款订单数
        cursor.execute('SELECT COUNT(*) as refunded FROM OrderDetails WHERE 是否退款 = "退款成功"')
        refunded = cursor.fetchone()['refunded']

        # 获取有效订单数
        cursor.execute('SELECT COUNT(*) as valid FROM OrderDetails WHERE 是否退款 != "退款成功" OR 是否退款 IS NULL')
        valid = cursor.fetchone()['valid']

        # 获取总订购数（有效订单）
        cursor.execute('SELECT SUM(订购数) as total_orders FROM OrderDetails WHERE 是否退款 != "退款成功" OR 是否退款 IS NULL')
        total_orders = cursor.fetchone()['total_orders'] or 0

        # 获取总让利后金额（有效订单）
        cursor.execute('SELECT SUM(让利后金额) as total_amount FROM OrderDetails WHERE 是否退款 != "退款成功" OR 是否退款 IS NULL')
        total_amount = cursor.fetchone()['total_amount'] or 0

        conn.close()

        return jsonify({
            'success': True,
            'stats': {
                'total_records': total,
                'unique_orders': unique_orders,
                'unique_products': unique_products,
                'refunded_orders': refunded,
                'valid_orders': valid,
                'total_order_quantity': int(total_orders),
                'total_discount_amount': float(total_amount)
            }
        })

    except Exception as e:
        print(f'获取统计信息时出错: {str(e)}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)