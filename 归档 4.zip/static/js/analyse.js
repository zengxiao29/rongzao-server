// 全局变量
let tabsConfig = [];
let currentTab = null;
let editingTab = null;

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    loadTabConfig();
    setupFileUpload();
    // 自动从数据库加载数据
    loadDataFromDb();
});

// 从数据库加载数据
async function loadDataFromDb() {
    try {
        const response = await fetch('/api/analyse/data');
        const data = await response.json();

        if (response.ok) {
            window.tabData = data.tabs;
            document.getElementById('tabSection').style.display = 'block';
            renderTableData(data.tabs);
        } else {
            alert('加载数据失败: ' + data.error);
        }
    } catch (error) {
        console.error('加载数据失败:', error);
        alert('加载数据失败: ' + error.message);
    }
}

// 加载 Tab 配置
async function loadTabConfig() {
    try {
        const response = await fetch('/api/analyse/config');
        const data = await response.json();
        tabsConfig = data.tabs || [];
        renderTabs();
    } catch (error) {
        console.error('加载 Tab 配置失败:', error);
    }
}

// 渲染 Tab 按钮
function renderTabs() {
    const tabContainer = document.getElementById('tabContainer');
    const existingTabs = tabContainer.querySelectorAll('.tab-button:not(.tab-actions button)');
    existingTabs.forEach(tab => tab.remove());

    tabsConfig.forEach((tab, index) => {
        const tabButton = document.createElement('button');
        tabButton.className = 'tab-button';
        tabButton.textContent = tab.name;
        tabButton.dataset.index = index;

        if (index === 0) {
            tabButton.classList.add('active');
            currentTab = index;
        }

        tabButton.onclick = function() {
            switchTab(index);
        };

        // 插入到 tab-actions 之前
        const tabActions = tabContainer.querySelector('.tab-actions');
        tabContainer.insertBefore(tabButton, tabActions);
    });

    // 如果没有 Tab，显示空状态
    if (tabsConfig.length === 0) {
        document.getElementById('tableContainer').innerHTML = `
            <div class="empty-state">
                <div style="font-size: 3rem;">📊</div>
                <p>请先添加 Tab 配置，然后点击"刷新数据"按钮</p>
            </div>
        `;
    }
}

// 切换 Tab
function switchTab(index) {
    currentTab = index;

    // 更新 Tab 按钮样式
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach((button, i) => {
        if (i === index) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    });

    // 如果已有数据，重新渲染表格
    if (window.tabData) {
        renderTableData(window.tabData);
    }
}

// 设置文件上传
function setupFileUpload() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const fileInfo = document.getElementById('fileInfo');
    const fileName = document.getElementById('fileName');

    uploadArea.addEventListener('click', (e) => {
        if (e.target.tagName !== 'BUTTON') {
            fileInput.click();
        }
    });

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleFile(file);
        }
    });

    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });

    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');

        const file = e.dataTransfer.files[0];
        if (file) {
            const fileName = file.name.toLowerCase();
            const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');

            if (isExcel) {
                handleFile(file);
            } else {
                alert('请上传Excel文件（.xlsx 或 .xls 格式）');
            }
        }
    });
}

// 处理文件
function handleFile(file) {
    // 直接上传文件，不显示文件信息
    uploadExcelFile(file);
}

// 上传 Excel 文件到数据库
async function uploadExcelFile(file) {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/analyse/upload', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (response.ok) {
            // 显示上传结果
            const resultDiv = document.getElementById('uploadResult');
            const resultText = document.getElementById('uploadResultText');
            
            resultText.innerHTML = `
                <strong>上传完成！</strong><br>
                总记录数: ${data.total}<br>
                成功插入: ${data.success_count}<br>
                重复忽略: ${data.duplicate_count}<br>
                错误: ${data.error_count}
            `;
            resultDiv.style.display = 'block';
            
            // 自动从数据库加载数据
            await loadDataFromDb();
        } else {
            alert('上传失败: ' + data.error);
        }
    } catch (error) {
        console.error('上传文件失败:', error);
        alert('上传文件失败: ' + error.message);
    }
}

// 渲染表格数据
function renderTableData(tabsData) {
    const tableContainer = document.getElementById('tableContainer');

    if (!tabsData || tabsData.length === 0) {
        tableContainer.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 3rem;">📊</div>
                <p>没有数据可显示</p>
            </div>
        `;
        return;
    }

    // 显示当前选中的 Tab 数据
    const currentTabData = tabsData[currentTab] || tabsData[0];

    if (!currentTabData || !currentTabData.data || currentTabData.data.length === 0) {
        tableContainer.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 3rem;">📊</div>
                <p>该 Tab 下没有数据</p>
            </div>
        `;
        return;
    }

    // 创建表格容器，包含编辑按钮
    let containerHTML = `
        <div class="table-wrapper">
            <div class="table-header">
                <button class="table-edit-button" onclick="openEditTabModal()">✎</button>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>商品类型</th>
                        <th>有效订购数</th>
                        <th>让利后金额</th>
                    </tr>
                </thead>
                <tbody>
    `;

    currentTabData.data.forEach(item => {
        containerHTML += `
            <tr>
                <td>${item.product_type}</td>
                <td>${item.valid_orders}</td>
                <td>${item.discount_amount.toFixed(2)}</td>
            </tr>
        `;
    });

    containerHTML += `
                </tbody>
            </table>
        </div>
    `;

    tableContainer.innerHTML = containerHTML;
}

// 打开新增 Tab 弹窗
function openAddTabModal() {
    editingTab = null;
    document.getElementById('modalTitle').textContent = '新增 Tab';
    document.getElementById('tabName').value = '';

    // 清空映射配置
    const mappingsContainer = document.getElementById('mappingsContainer');
    mappingsContainer.innerHTML = `
        <div class="mapping-row">
            <input type="text" class="product-input" placeholder="商品名称" />
            <input type="text" class="type-input" placeholder="商品类型名称" />
            <button class="remove-mapping" onclick="removeMapping(this)">删除</button>
        </div>
    `;

    document.getElementById('tabModal').classList.add('show');
}

// 打开编辑 Tab 弹窗
function openEditTabModal(index) {
    if (index === undefined) {
        index = currentTab;
    }

    if (index === null || !tabsConfig[index]) {
        alert('请先选择一个 Tab');
        return;
    }

    editingTab = index;
    const tab = tabsConfig[index];

    document.getElementById('modalTitle').textContent = '编辑 Tab';
    document.getElementById('tabName').value = tab.name;

    // 填充映射配置
    const mappingsContainer = document.getElementById('mappingsContainer');
    mappingsContainer.innerHTML = '';

    tab.mappings.forEach(mapping => {
        addMappingRow(mapping.product, mapping.type);
    });

    // 如果没有映射，添加一个空行
    if (tab.mappings.length === 0) {
        addMappingRow();
    }

    document.getElementById('tabModal').classList.add('show');
}

// 添加映射行
function addMapping() {
    addMappingRow();
}

function addMappingRow(product = '', type = '') {
    const mappingsContainer = document.getElementById('mappingsContainer');
    const row = document.createElement('div');
    row.className = 'mapping-row';
    row.innerHTML = `
        <input type="text" class="product-input" placeholder="商品名称" value="${product}" />
        <input type="text" class="type-input" placeholder="商品类型名称" value="${type}" />
        <button class="remove-mapping" onclick="removeMapping(this)">删除</button>
    `;
    mappingsContainer.appendChild(row);
}

// 删除映射行
function removeMapping(button) {
    const mappingsContainer = document.getElementById('mappingsContainer');
    if (mappingsContainer.children.length > 1) {
        button.parentElement.remove();
    } else {
        alert('至少保留一个映射配置');
    }
}

// 关闭弹窗
function closeModal() {
    document.getElementById('tabModal').classList.remove('show');
}

// 保存 Tab 配置
async function saveTabConfig() {
    const tabName = document.getElementById('tabName').value.trim();

    if (!tabName) {
        alert('请输入 Tab 名称');
        return;
    }

    // 获取映射配置
    const mappingRows = document.querySelectorAll('.mapping-row');
    const mappings = [];

    mappingRows.forEach(row => {
        const product = row.querySelector('.product-input').value.trim();
        const type = row.querySelector('.type-input').value.trim();

        if (product && type) {
            mappings.push({ product, type });
        }
    });

    if (mappings.length === 0) {
        alert('请至少添加一个商品映射配置');
        return;
    }

    const tabData = {
        name: tabName,
        mappings: mappings
    };

    if (editingTab !== null) {
        // 编辑现有 Tab
        tabsConfig[editingTab] = tabData;
    } else {
        // 新增 Tab
        tabsConfig.push(tabData);
    }

    // 保存到服务器
    try {
        const response = await fetch('/api/analyse/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tabs: tabsConfig })
        });

        const data = await response.json();

        if (response.ok) {
            renderTabs();
            closeModal();

            // 从数据库重新加载数据
            await loadDataFromDb();

            alert('保存成功');
        } else {
            alert('保存失败: ' + data.error);
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('保存失败: ' + error.message);
    }
}

// 删除 Tab
async function deleteTab(index) {
    if (index === undefined) {
        index = currentTab;
    }

    if (index === null || !tabsConfig[index]) {
        alert('请先选择一个 Tab');
        return;
    }

    if (!confirm(`确定要删除 Tab "${tabsConfig[index].name}" 吗？`)) {
        return;
    }

    tabsConfig.splice(index, 1);
    currentTab = tabsConfig.length > 0 ? 0 : null;

    // 保存到服务器
    try {
        const response = await fetch('/api/analyse/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tabs: tabsConfig })
        });

        const data = await response.json();

        if (response.ok) {
            renderTabs();
            // 从数据库重新加载数据
            await loadDataFromDb();
            alert('删除成功');
        } else {
            alert('删除失败: ' + data.error);
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('删除失败: ' + error.message);
    }
}